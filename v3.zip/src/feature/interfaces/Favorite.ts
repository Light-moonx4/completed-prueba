import type { Event } from './Product';

export interface Favorite {
  id: string;
  eventId: string;
  userId: string;
  events?: Event;
  createdAt?: string;
}
