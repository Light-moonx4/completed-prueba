import { useEffect, useState } from 'react';
import type { Category } from '../../interfaces/Category';
import type { CreateEvent, Event } from '../../interfaces/Product';
import { FormField } from '../common/FormField';

interface EventFormProps {
  categories: Category[];
  /** Si viene definido, el categoryId ya no es editable (entrada desde la vista de categoría). */
  fixedCategoryId?: string;
  initialEvent?: Event;
  submitLabel?: string;
  onSubmit: (data: CreateEvent) => Promise<void>;
}

type FormState = {
  name: string;
  description: string;
  price: string;
  capacity: string;
  date: string;
  location: string;
  categoryId: string;
  images: string;
};

const emptyState: FormState = { name: '', description: '', price: '', capacity: '', date: '', location: '', categoryId: '', images: '' };

/**
 * Un solo componente, reutilizado en dos entradas distintas (desde una categoría
 * con categoryId precargado, o desde la zona general de productos con el <select>
 * de categorías) y también para editar un producto existente.
 */
export function EventForm({ categories, fixedCategoryId, initialEvent, submitLabel = 'Guardar', onSubmit }: EventFormProps) {
  const [form, setForm] = useState<FormState>(emptyState);
  const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>({});
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  // Sincroniza el formulario cuando llegan datos externos (producto cargado de forma
  // asíncrona para edición, o categoryId fijo al entrar desde una categoría).
  /* eslint-disable react-hooks/set-state-in-effect */
  useEffect(() => {
    if (initialEvent) {
      setForm({
        name: initialEvent.name,
        description: initialEvent.description ?? '',
        price: String(initialEvent.price),
        capacity: String(initialEvent.capacity),
        date: initialEvent.date ?? '',
        location: initialEvent.location ?? '',
        categoryId: initialEvent.categoryId,
        images: initialEvent.images ?? '',
      });
    } else if (fixedCategoryId) {
      setForm((prev) => ({ ...prev, categoryId: fixedCategoryId }));
    }
  }, [initialEvent, fixedCategoryId]);
  /* eslint-enable react-hooks/set-state-in-effect */

  const update = (field: keyof FormState) => (value: string) => setForm((prev) => ({ ...prev, [field]: value }));

  const validate = (): boolean => {
    const next: Partial<Record<keyof FormState, string>> = {};
    if (!form.name.trim()) next.name = 'El nombre es obligatorio.';
    if (!form.price || Number(form.price) <= 0) next.price = 'El precio debe ser mayor a 0.';
    if (!form.capacity || Number(form.capacity) < 0) next.capacity = 'La capacidad no puede ser negativa.';
    if (!form.date) next.date = 'La fecha es obligatoria.';
    if (!form.location.trim() || form.location.trim().length < 2)
      next.location = 'La ubicación debe tener al menos 2 caracteres.';
    if (!form.categoryId) next.categoryId = 'Selecciona una categoría.';
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError(null);
    if (!validate()) return;

    setSubmitting(true);
    try {
      await onSubmit({
        name: form.name.trim(),
        description: form.description.trim() || undefined,
        price: Number(form.price),
        capacity: Number(form.capacity),
        date: form.date,
        location: form.location.trim(),
        categoryId: form.categoryId,
        images: form.images.trim() || undefined,
      });
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : 'No se pudo guardar el producto.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4">
      <FormField label="Nombre" name="name" value={form.name} onChange={update('name')} error={errors.name} required />
      <FormField label="Descripción" name="description" as="textarea" value={form.description} onChange={update('description')} />
      <div className="grid grid-cols-2 gap-4">
        <FormField label="Precio" name="price" type="number" value={form.price} onChange={update('price')} error={errors.price} required />
        <FormField label="Capacidad" name="capacity" type="number" value={form.capacity} onChange={update('capacity')} error={errors.capacity} required />
      </div>

      <FormField label="Fecha" name="date" type="date" value={form.date} onChange={update('date')} error={errors.date} required />
      <FormField label="Ubicación" name="location" value={form.location} onChange={update('location')} error={errors.location} required />

      {fixedCategoryId ? (
        <div className="flex flex-col gap-1">
          <span className="text-sm font-medium text-slate-700">Categoría</span>
          <select
            disabled
            value={fixedCategoryId}
            className="w-full rounded-lg border border-slate-200 bg-slate-100 px-3 py-2 text-sm text-slate-500"
          >
            {categories
              .filter((c) => c.id === fixedCategoryId)
              .map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
          </select>
        </div>
      ) : (
        <div className="flex flex-col gap-1">
          <label htmlFor="categoryId" className="text-sm font-medium text-slate-700">
            Categoría <span className="text-red-500">*</span>
          </label>
          <select
            id="categoryId"
            value={form.categoryId}
            onChange={(e) => update('categoryId')(e.target.value)}
            className={`w-full rounded-lg border px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-500 ${
              errors.categoryId ? 'border-red-400' : 'border-slate-300'
            }`}
          >
            <option value="">Selecciona una categoría</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
          {errors.categoryId && <p className="text-xs text-red-600">{errors.categoryId}</p>}
        </div>
      )}

      <FormField label="URL de la imagen" name="images" value={form.images} onChange={update('images')} />
      <p className="-mt-2 text-xs text-slate-400">
        Usa clic derecho → "Copiar dirección de la imagen" sobre la imagen (no la URL de la página de resultados).
      </p>

      {submitError && <p className="text-sm text-red-600">{submitError}</p>}

      <button
        type="submit"
        disabled={submitting}
        className="rounded-lg bg-indigo-600 px-4 py-2 font-medium text-white hover:bg-indigo-700 disabled:opacity-50"
      >
        {submitting ? 'Guardando...' : submitLabel}
      </button>
    </form>
  );
}
