import { request } from './api';
import type { Favorite } from '../interfaces/Favorite';

export const favoriteService = {
  getMine() {
    return request<Favorite[]>({ url: '/favorites', method: 'GET' });
  },
  add(eventId: string) {
    return request<Favorite>({ url: '/favorites', method: 'POST', data: { eventId } });
  },
  remove(eventId: string) {
    return request<void>({ url: `/favorites/${eventId}`, method: 'DELETE' });
  },
};
