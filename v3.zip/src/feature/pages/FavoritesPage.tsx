import { useFetch } from '../hooks/useFetch';
import { favoriteService } from '../services/favoriteService';
import { useFavorites } from '../context/FavoritesContext';
import { EventCard } from '../components/events/EventCard';
import { Spinner } from '../components/common/Spinner';
import { ErrorState } from '../components/common/ErrorState';
import { EmptyState } from '../components/common/EmptyState';

/** Requiere sesión (protegida por <ProtectedRoute />). Lista los productos guardados. */
export function FavoritesPage() {
  // Se suscribe al mismo estado que usa el ícono de cada producto: cuando favoriteIds
  // cambia (agregar/quitar desde cualquier parte de la app), se refetch y la lista
  // se actualiza sin necesidad de recargar la página.
  const { favoriteIds } = useFavorites();
  const favoriteKey = Array.from(favoriteIds).sort().join(',');
  const { data: favorites, loading, error, refetch } = useFetch(() => favoriteService.getMine(), [favoriteKey]);

  if (loading) return <Spinner />;
  if (error) return <ErrorState message={error.message} onRetry={refetch} />;

  const events = (favorites ?? [])
    .map((fav) => fav.events)
    .filter((p): p is NonNullable<typeof p> => Boolean(p));

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <h1 className="mb-6 text-2xl font-bold text-slate-800">Mis favoritos</h1>
      {events.length === 0 ? (
        <EmptyState message="Todavía no has guardado eventos como favoritos." />
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
          {events.map((event) => (
            <EventCard key={event.id} event={event} />
          ))}
        </div>
      )}
    </div>
  );
}
